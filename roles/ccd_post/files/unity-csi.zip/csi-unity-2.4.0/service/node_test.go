package service

import (
	"testing"
)

func TestNodeGetInfo(t *testing.T) {
	//fmt.Println(testConf.service.arrays)
	//testConf.service.nodeProbe(testConf.ctx, "")
	//testConf.service.discoverNodes(testConf.ctx, "1")
	//time.Sleep(30 * time.Second)
}
